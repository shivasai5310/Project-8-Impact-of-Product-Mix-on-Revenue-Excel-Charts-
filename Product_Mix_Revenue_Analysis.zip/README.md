# Product Mix Revenue Analysis

## Overview
This Excel-based project evaluates how different product mix strategies affect total revenue. Using hypothetical data for five product categories, we analyze three sales scenarios and visualize the impact of each mix.

## Features
- Product categories with varying prices and units sold
- Scenario-based revenue simulation using SUMPRODUCT
- Visual insights using stacked bar and pie charts

## How to Use
1. Open the Excel file `product_mix_analysis.xlsx`
2. Review product pricing and units sold across three scenarios
3. Analyze the calculated revenue under each scenario
4. Create charts using Excel to visualize the product mix contributions

## Author
Timmaiahgari Shivasai
